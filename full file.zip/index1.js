const express = require('express')
const app = express()
const kambingRouter = require('./router/kambing')


app.use(express.json())
app.use(express.urlencoded({extended: true}))

// app.use(kambingRouter)
// app.route('/kambing')
//     .get(function (req, res){
//     res.send('Tampilkan data kambing yang tersedia')
//     })
//     .post(function (req, res){
//     res.send('Tambahkan data kambing')
//     })
//     .put(function (req, res){
//     res.send('Update data kambing yang tersedia')
//     })
//     .delete(function (req, res){
//     res.send('Hapus data kambing')
//     })
// app.get('/', function(req, res){
//     res.send("Selamat Datang Di FaridFarm")
// })
// //menampilkan data json
// app.get('/goat', function(req, res){
//     const kambing = {
//         id : 1,
//         Nama : "Jabal",
//         Harga : "Rp. 2.000.000",
//         Keterangan : "Tersedia"
//     }
//     res.json(kambing)
// })
// //mengakses halaman luar
// app.get('/url', function(req, res){
//     res.redirect('https://nextjs.org/')
// })
// //mengirimkan pesan jika salah memasukkan alamat
// app.get('/urli', function(req, res){
//     res.sendStatus(404)
// })
// app.get('/about', function(req, res){
//     res.send("FaridFarm adalah tempat penjualan segala jenis kambing terbaik di Banyuwangi")
// })
// app.post('/about', function(req, res){
//     res.send("Post : FaridFarm adalah tempat penjualan segala jenis kambing terbaik di Banyuwangi")
// })
// app.put('about', function(req, res){
//     res.send("Put : FaridFarm adalah tempat penjualan segala jenis kambing terbaik di Banyuwangi")
// })
// app.put('/goat/:id/:nama/:harga/:keterangan', function(req, res){
//     res.send(req.params)
// })
// app.delete('/about', function(req, res){
//     res.send("Delete : FaridFarm adalah tempat penjualan segala jenis kambing terbaik di Banyuwangi")
// })
app.use(kambingRouter)
app.listen(3000, function (req, res){
    console.log('Server Berjalan')
})

