const express = require('express')
const router = express.Router()
const kambingController= require('./contollers/kambing')
// const kambingRouter =require('./router/kambing')
// router.route('/kambing')
//     .get(kambingController.index)
//     .post(kambingRouter.tambah)
// router.put('/kambing/id', kambingController.update)
// router.delete('/kambing/:id', kambing.delete)
router.route('/kambing')
.get(kambingController.index)
// app.listen(3000, function(req, res){
//     console.log('server berjalan')
// })
module.exports = router




// router.put('/kambing/:id', function(req, res){
//     const id = req.params.id
//     kambing.filter(kbg =>{
//         if (kbg.id == id){
//             kbg.id = id
//             kbg.nama = req.body.nama
//             kbg.harga = req.body.harga
//             kbg.keterangan = req.body.keterangan
//             return kambing
//         }
//     })
//     res.json(kambing)
// })
// router.delete('/kambing/:id', function(req, res){
//     const id = req.params.id
//     kambing.filter(kbg =>{
//         if (kbg.id == id){
//             var index = kambing.indexOf(kbg)
//             kambing.splice(index, 1)

//             return kambing
//         }
//     })
//     res.json(kambing)
//     res.send(kambing)
// })
// router.route('/kambing')
//     .get(function(req, res){
//         if (kambing.length >0){
//             res.json({
//                 status : true,
//                 data: kambing,
//                 method: req.method,
//                 URL: req.url
//             })
//         }
//         else{
//             res.json({
//                 status: false,
//                 massage: 'Tidak ada kambing yang tersedia'
//             })
//         }
//         res.json(kambing)
//     })
router.route('/kambing')
    .post(function(req, res){
    kambing.push(req.body)
        res.send({
            status: true,
            data: kambing,
            massage: 'Data kambing berhasil ditambahkan',
            method: req.method,
            URL: req.url
        })
    })
// router.put('/kambing/:id', function (req, res){
//     const id = rfeq.params.id;
//     let ada = false
//     kambing.filter(kbg =>{
//         if (kbg.id == id){
//             kbg.nama = req.body.nama
//             kbg.harga = req.body.harga
//             kbg.keterangan = req.body.keterangan
//             res.send({
//                 status: true,
//                 data : kambing,
//                 massage: 'Data Kambing Berhasil di Update',
//                 method : req.method,
//                 url: req.url
//             })
//             ada = true
//             return kambing
//         }
//     })
//     res.json(kambing)
// })
// router.delete('/kambing/:id', function(req, res){
//     const id = req.params.id
//     kambing,filter(kbg=>{
//         if   (kbg.id == id){
//             res.send({
//                 status: true,
//                 data: kambing,
//                 massage: 'Data Kambing Berhasil Dihapus',
//                 method: req.method,
//                 url: req.url
//             })
//             var index = kambing.indexOf(kbg)
//             kambing.slice(index, 1)
//         }
//     })
//     res.json(kambing)
//     res.send(kambing)
// })  
// router.route('/kambing')
// let kambing = [
//     {id: 1, nama: 'jamal', harga: 'Rp. 2.000.000', keterangan : 'tersedia'},
//     {id: 2, nama: 'jamil', harga: 'Rp. 2.500.000', keterangan : 'tersedia'}
//     // {id: 3, nama: 'junaidi', harga: 'Rp. 2.350.000', keterangan : 'tersedia'}
// ]
// router.route('/kambing')
//     .get(function (req, res){
//         res.json(kambing)
//     })
//     .post(function (req, res){
//         kambing.push(req.body)
//         // res.send('Tambahkan data kambing')
//         // res.send(req.body)
//         res.send(kambing)
//     })
// module.exports = {
//     index: function(req,res){
//         if (kambing.length>0){
//             res.json({
//                 status: true,
//                 data : kambing,
//                 method : req.method,
//                 URL: req.url
//             })
//         }
//         else{
//             res.json({
//                 status: false,
//                 massage:"Data Kambing masih kosong"
//             })
//         }
//     },
//     tambah: function(req, res){
//         kambing.push(req.body)
//         res.send({
//             status: true,
//             data : kambing, 
//             massage: "Data Kambing Berhasil Ditambahkan",
//             method: req.method,
//             URL : req.url
//         })
//     },
//     update: function(req, res){
//         const id = req.params.id;
//         let ada = false
//         kambing.filter(kbg=>{
//             if (kbg.id == id){
//                 kbg.id = id
//                 kbg.nama = nama
//                 kbg.harga = harga
//                 kbg.keterangan = keterangan
//                 res.send({
//                     status : true,
//                     data : kambing,
//                     massage : "Data Kambing Berhasil di Update",
//                     method : req.method,
//                     url : req.url
//                 })
//                 ada = true;
//                 return kambing
//             }
//         })
//         res.json(kambing)
//     },
//     delete: function (req,res){
//         const id = req.params.id
//         kambing.filter(kbg  =>{
//             if(kbg.id == id){
//                 res.send({
//                     status: true,
//                     data : kambing,
//                     massage: 'Data Kambing berhasil di hapus',
//                     method : req.method,
//                     url: req.url
//                 })
//                 var index= kambing.indexOf(kbg)
//                 kambing.splice(index, 1)
//             }
//         })
//         res.json(kambing)
//         res.send(kambing)
//     }
// }
//     .get(function(req, res){
//         res.send('Tampilkan data kambing yang tersedia')
//     })
//     .post(function(req, res){
//         res.send('Tmbahkan data kambing')
//     })
// router.put('/kambing/:id', function(req, res){
//     res.send(req.params.id)
// })
// router.delete('/kambing/:id', function(req, res){
//     const id = req.params
//     res.send(id)
// })
// module.exports = router